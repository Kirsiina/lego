package data;

public class Data {

	public static boolean shouldRun = true;
	public static boolean colorDetected = true;
	public static float color = 0.1f;
	public static int speed = 200;

	
}
