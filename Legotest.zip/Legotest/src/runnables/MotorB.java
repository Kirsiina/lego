package runnables;

public class MotorB {

	//t�h�n siis vasemman puolen moottorin k�skytys, jos muunnetaan
	
}
