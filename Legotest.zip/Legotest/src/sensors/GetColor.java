package sensors;

import data.Data;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.Color;
import lejos.robotics.SampleProvider;

public class GetColor {
	
//	EV3ColorSensor	sensor;
//	SampleProvider sp;
//	float[]		sample;
//	
//	
//	
//	public GetColor(Port port) {
//		sensor = new EV3ColorSensor(port);
//		sp = sensor.getRedMode();
//		sample = new float[sp.sampleSize()];
//	}
//	
//	public EV3ColorSensor getSensor()
//	{
//		return sensor;
//	}
//	
//	public void setRedMode()
//	{
//		sensor.setCurrentMode(Color.RED);
//		sample = new float[sensor.sampleSize()];
//	}
//	
//	public float getRed()
//	{
//		sp.fetchSample(sample, 0);
//		Data.color = sample[0];
//		return Data.color;
//	}

}
